# Dte Fast Api

## Requeriments 
- Virtualenv
- Python3

## How to configure

1. cd $workdir
2. virtualenv .
3. source bin/activate
4. pip install -r requirements.txt
5. uvicorn main:app --reload

## Help

### Instalar o Actualizar Pip
1. python3 -m pip install --upgrade pip
### Instalar o Actualizar Virtualenv
2. python3 -m pip install --upgrade virtualenv
