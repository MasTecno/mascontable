import requests_pkcs12
import requests
import base64
from fastapi import FastAPI
from typing import Optional
from pydantic import BaseModel
from datetime import date, datetime
from fastapi.responses import HTMLResponse
import json

class SyncData(BaseModel):
    rutCompany: str
    cert: Optional[str] = None
    password: str
    periodo: str
    operacion: str

app = FastAPI()

def Auth(rut, cert, password):
    URL = 'https://herculesr.sii.cl/cgi_AUT2000/CAutInicio.cgi'

    payload = {
        'rutcntr':rut,
        'rut':rut.split('-')[0],
        'dv':rut.split('-')[1],
        'referencia':'https://www.sii.cl',
    }

    r = requests_pkcs12.post(
        URL,
        data=payload,
        pkcs12_data=base64.b64decode(cert), 
        pkcs12_password=password,
        verify=True,
    )

    cookies = None
    
    if r.status_code in range(200,201):
        cookies = r.cookies
    
    return cookies

def AuthWithOutCert(rut, password):
    URL = 'https://zeusr.sii.cl//cgi_AUT2000/CAutInicio.cgi'

    x = rut.split('-')[0]

    payload = {
        'clave':password,
        'rut':x.split('.')[0]+x.split('.')[1]+x.split('.')[2],
        'dv':rut.split('-')[1],
        'rutcntr':rut,
        'referencia':'https://www.sii.cl',
        '411':''
    }
    r = requests.post(
        URL,
        data=payload,
    )

    cookies = None
    
    if r.status_code in range(200,201):
        cookies = r.cookies
    
    return cookies

@app.get("/")
async def root():
    return {"message": "Hello World"}
    
@app.post("/api/sync_sii")
async def send(data: SyncData):
    if data.cert == None:
        cookies = AuthWithOutCert(data.rutCompany, data.password)
    else:
        cookies = Auth(data.rutCompany, data.cert, data.password)


    if cookies is None:
        return {
            'success': False,
            'message': "Error al iniciar sesion"
        }
    
    BASEURL = 'https://www4.sii.cl'
    AMBIENTE = '/consdcvinternetui'
    NAMESPACE = 'cl.sii.sdi.lob.diii.consdcv.data.api.interfaces.FacadeService/'

    rutCompany = data.rutCompany.split('-')[0] 
    dvCompany = data.rutCompany.split('-')[1]

    url_resumen = AMBIENTE + '/services/data/facadeService/getResumen'

    if data.operacion == "VENTA":
        url_detalle     = AMBIENTE + '/services/data/facadeService/getDetalleVenta'
    else :
        url_detalle     = AMBIENTE + '/services/data/facadeService/getDetalleCompra'
    
    # se envia solicitud de folios
    payload = {
        "metaData": { 
            "namespace":NAMESPACE + 'getResumen',
            "conversationId": cookies['TOKEN'],
            "transactionId": "0f3933d9-3991-4fdb-8b0a-df00e1fbcaf9",
            "page":None
        },
        "data": { 
            "ptributario": data.periodo,
            "rutEmisor":  rutCompany.replace(".", ""),
            "dvEmisor": dvCompany,
            "operacion": data.operacion,
            "estadoContab": "REGISTRO"
        }
    }
    headers = {
        "content-type": "application/json",
        "Accept": "application/json, text/plain, */*"
    }

    resp = requests.post(BASEURL+url_resumen, data=json.dumps(payload), cookies=cookies, headers=headers)

    if resp.status_code != 200:
        return {
            'success': False,
            'message': "Error de comunicación 1"
        }

    if resp.json()["respEstado"]["codRespuesta"] == 99:
        return {
            'success': False,
            'message': resp.json()['respEstado']['msgeRespuesta']
        }

    resumenes = resp.json()["data"]

    dtes = dict()

    for resumen in resumenes:
        if resumen['rsmnTotDoc'] == 0: 
            continue

        if data.operacion == "COMPRA":
            serviceDetalle = "getDetalleCompra"
        else :
            serviceDetalle = "getDetalleVenta"
        
        body_detalle = {
            "metaData": {
                "namespace": NAMESPACE + serviceDetalle,
                "conversationId": cookies['TOKEN'],
                "transactionId": "a9d2f9a6-4126-4f99-867c-1e0f73153675",
                "page": None
            },
            "data" : {
                "codTipoDoc": resumen['rsmnTipoDocInteger'],
                "rutEmisor": rutCompany.replace(".", ""),
                "dvEmisor": dvCompany,
                "ptributario": data.periodo,
                "operacion": data.operacion,
                "estadoContab": "REGISTRO"
            }
        }

        response_detalle = requests.post(BASEURL+url_detalle, data=json.dumps(body_detalle), cookies=cookies, headers=headers)

        if response_detalle.status_code != 200:
            return {
                'success': False,
                'message': "Error de comunicación 2"
            }

        if len(response_detalle.json()['data']) == 0:
            continue

        for detalle in response_detalle.json()['data']:
            if str(resumen['rsmnTipoDocInteger']) not in dtes:
                dtes[str(resumen['rsmnTipoDocInteger'])] = []

            dtes[str(resumen['rsmnTipoDocInteger'])].append(detalle)
        
    return {
        'success': True,
        'data': dtes
    }